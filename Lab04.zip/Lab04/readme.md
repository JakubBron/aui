# How to start?
1. Run GatewayApplication.
2. Run CharacterService.
3. Run ProfessionService.

# Default ports:
- Gateway: 8080
- CharacterService: 8082
- ProfessionsService: 8081

# Where to configure?
In `application.properties`. \
! Remember about changing `game.character-service.url` and `game.profession-service.url` in `Gateway` and `ProfessionService` !