package com.example.CharacterService.CharacterService.lab03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
