# How to start?
1. Run GatewayApplication.
2. Run CharacterService.
3. Run ProfessionService.
4. Run frontend using start.ps1 script.

# Default ports:
- Gateway: 8080
- App: 4200