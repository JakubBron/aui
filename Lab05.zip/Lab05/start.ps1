cd GameFrontend
ng serve --proxy-config src/proxy.conf.json