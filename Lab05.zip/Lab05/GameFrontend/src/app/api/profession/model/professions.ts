interface Profession {
  id: string;
  name: string;
}

export interface Professions {
  professions: Profession[];
}
