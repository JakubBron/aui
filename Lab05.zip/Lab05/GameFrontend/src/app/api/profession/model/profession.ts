export interface Profession {
  id: string;
  name: string;
  yearsOfExperience: number;
}
