export interface Character {
  id: string;
  name: string;
  age: number;
  level: number;
}
