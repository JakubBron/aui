interface Character {
  id: string;
  name: string;
}

export interface Characters {
  characters: Character[];
}
