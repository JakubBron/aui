import {
  MatDivider,
  MatDividerModule
} from "./chunk-DXLSYD3M.js";
import "./chunk-K4U3JJF5.js";
import "./chunk-BENP2FU6.js";
import "./chunk-ZEBJVTGM.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
