import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-3S3PNBOL.js";
import "./chunk-XVZ3RVQ2.js";
import "./chunk-MWNZX5KB.js";
import "./chunk-44JQ5FZC.js";
import "./chunk-NQ4HTGF6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
